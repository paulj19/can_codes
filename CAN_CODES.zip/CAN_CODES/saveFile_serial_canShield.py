import serial
f = open("ard_serial.txt", 'w')
ser = serial.Serial('/dev/ttyACM0', 9600)
while True:
    rcvd_data  = ser.readline()
    print rcvd_data
    f.write(rcvd_data)

ser.close()

