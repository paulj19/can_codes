
#include <stdio.h>
#include <linux/can.h>
#include <linux/if.h>
#include <linux/can/raw.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/types.h>

#include <string.h>
int main()
{
  int in, out;
  int nbytes;
  int i;

  struct sockaddr_can addr_in, addr_out;
  struct ifreq ifr_in, ifr_out;
  struct can_frame frame;

  in = socket(PF_CAN, SOCK_RAW, CAN_RAW);
  out = socket(PF_CAN, SOCK_RAW, CAN_RAW);

  /*naming the interface*/
  strcpy(ifr_in.ifr_name, "vcanIN");
  strcpy(ifr_out.ifr_name, "vcanOUT");

  ioctl(in, SIOCGIFINDEX, &ifr_in);
  ioctl(out, SIOCGIFINDEX, &ifr_out);

  /*getting the interface index*/
  addr_in.can_family = AF_CAN;
  addr_in.can_ifindex = ifr_in.ifr_ifindex;

  addr_out.can_family = AF_CAN;
  addr_out.can_ifindex = ifr_out.ifr_ifindex;

  /*binding to a socket*/
  bind(in, (struct sockaddr *)&addr_in, sizeof(addr_in));
  bind(out, (struct sockaddr *)&addr_out, sizeof(addr_out));


  while(1){

  /*reading the can frame*/
    nbytes = read(in, &frame, sizeof(struct can_frame));
  
  /*resending the can frame to the other interface*/
    write(out, &frame, sizeof(struct can_frame));
  
    printf("\n %s \t  %X\t[%d] \t", ifr_in.ifr_name, frame.can_id, frame.can_dlc);

    for(i=0; i < frame.can_dlc; i++)
      printf("%02X ", frame.data[i]);
  }
  return 0;
}
