
#include <stdio.h>
#include <linux/can.h>
#include <linux/if.h>
#include <linux/can/raw.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/types.h>

#include <string.h>

#define BRIDGE_MODE

int main()
{
  int in;
  int nbytes;
  int i;

  //char ctrlmsg[CMSG_SPACE(sizeof(struct timeval) + 3*sizeof(struct timespec) + sizeof(__u32))];

  struct msghdr msg;
  struct iovec iov;
  struct sockaddr_can addr;
  struct ifreq ifr_in;
  struct can_frame frame;

  can0_soc = socket(PF_CAN, SOCK_RAW, CAN_RAW);
 

  strcpy(ifr_in.ifr_name, "can0_");

  ioctl(can0_soc, SIOCGIFINDEX, &ifr_in);

  addr.can_family = AF_CAN;
  addr.can_ifindex = ifr_in.ifr_ifindex;

  bind(can0_soc, (struct sockaddr *)&addr, sizeof(addr));

  iov.iov_base = &frame;
  msg.msg_name = &addr;
  msg.msg_iov = &iov;
  msg.msg_iovlen = 1;
  msg.msg_control = NULL;


  iov.iov_len = sizeof(frame);
  msg.msg_namelen = sizeof(addr);
  msg.msg_controllen = 0;
  msg.msg_flags = 0;
  
  ifr_in.can_id = 






}
