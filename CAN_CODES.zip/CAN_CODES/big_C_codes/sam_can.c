#include <stdio.h>
#include <linux/can.h>
#include <linux/if.h>
#include <linux/can/raw.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/types.h>

#include <string.h>

#define BRIDGE_MODE

int main()
{
  int in, out;
  int nbytes, nbytes_in;
  int i;

  //char ctrlmsg[CMSG_SPACE(sizeof(struct timeval) + 3*sizeof(struct timespec) + sizeof(__u32))];

  struct msghdr msg;
  struct iovec iov;

  struct msghdr msg_module;
  struct iovec iov_module;

  struct sockaddr_can addr, addr_module;
  struct ifreq ifr_in, ifr_out;
  struct can_frame frame, frame_module;

  in = socket(PF_CAN, SOCK_RAW, CAN_RAW);
  out = socket(PF_CAN, SOCK_RAW, CAN_RAW);

  /*naming the interface*/
  strcpy(ifr_in.ifr_name, "vcanIN");
  strcpy(ifr_out.ifr_name, "vcanOUT");

  ioctl(in, SIOCGIFINDEX, &ifr_in);
  ioctl(out, SIOCGIFINDEX, &ifr_out);

  /*getting the interface index*/
  addr.can_family = AF_CAN;
  addr.can_ifindex = ifr_in.ifr_ifindex;

  addr_module.can_family = AF_CAN;
  addr_module.can_ifindex = ifr_out.ifr_ifindex;

  /*binding to a socket*/
  bind(in, (struct sockaddr *)&addr, sizeof(addr));
  bind(out, (struct sockaddr *)&addr_module, sizeof(addr_module));
  
  iov.iov_base = &frame;
  msg.msg_name = &addr;
  msg.msg_iov = &iov;
  msg.msg_iovlen = 1;
  msg.msg_control = NULL;
  
#ifdef BRIDGE_MODE //bridge mode
  iov_module.iov_base = &frame_module;
  msg_module.msg_name = &addr_module;
  msg_module.msg_iov = &iov_module;
  msg_module.msg_iovlen = 1;
  msg_module.msg_control = NULL;
#endif
  while(1){

    iov.iov_len = sizeof(frame);
    msg.msg_namelen = sizeof(addr);
    msg.msg_controllen = 0;
    msg.msg_flags = 0;

  /*reading from can bus*/
   // nbytes = read(in, &frame, sizeof(struct can_frame));
    nbytes = recvmsg(in, &msg, 0);
    if(nbytes < 0){
      perror("can raw socket read");
    } 
    if(nbytes < (sizeof (struct can_frame))){
      fprintf(stderr, "read: incomplete CAN frame \n");
      return 1;
    }

#ifndef BRIDGE_MODE
   printf("\n %s \t  %x\t[%d] \t", ifr_in.ifr_name, frame.can_id, frame.can_dlc);

    for(i=0; i < frame.can_dlc; i++)
      printf("%02X ", frame.data[i]);
#endif

#ifdef BRIDGE_MODE //bridge mode

    iov_module.iov_len = sizeof(frame_module);
    msg_module.msg_namelen = sizeof(addr_module);
    msg_module.msg_controllen = 0;
    msg_module.msg_flags = 0;

//    write(out, &frame, sizeof(struct can_frame));

    nbytes_in = recvmsg(out, &msg_module, 0);

    if(nbytes_in < 0){
      perror("can raw socket read");
    } 
    if(nbytes_in < (sizeof (struct can_frame))){
      fprintf(stderr, "read: incomplete CAN frame \n");
      return 1;
    }
    printf("\n %s \t  %x\t[%d] \t", ifr_out.ifr_name, frame_module.can_id, frame_module.can_dlc);

    for(i=0; i < frame_module.can_dlc; i++)
      printf("%02X ", frame_module.data[i]);
  
#endif

  }
  close(in);
  close(out);
  return 0;
}



