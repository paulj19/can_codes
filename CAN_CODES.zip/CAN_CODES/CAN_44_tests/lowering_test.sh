#!/bin/bash

sudo ip link set can0 type can bitrate 500000
sudo ip link set can0 up

cansend can0 5a0#0000dd0000000000
