#!/bin/bash

while [ true ]; do
	cansend can0 133#0204000800000000
done
