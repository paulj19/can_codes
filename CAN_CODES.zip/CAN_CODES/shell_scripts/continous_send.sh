#!/bin/bash

sudo ip link set can0 type can bitrate 500000
sudo ip link set can0 up
#counter=42
#while [ $counter -gt 0 ]; do
cansend can0 149#6302
    sleep .004
cansend can0 03D#7C0A000000000000
    sleep .004
cansend can0 351#100E54AFAAEAF000
    sleep .004
#done

#countery=40
#while [ $countery -gt 0 ]; do
##	cansend vcan2 001#0000000000000000
##	cansend can0 133#0200000000000000
#	cansend can0 641#242020202020202B
#    sleep .02
#    #cansend can0 401#0080000000FFC080
#    #cansend can0 401#0080004000FFC080
#    let countery-=1
#    echo $countery
#
#    sleep .08
#done
##    sleep .085
##    cansend can0 401#0080000000FFC080
##    sleep .085
##	cansend can0 133#0200000000000000
##   sleep .085
##    cansend can0 401#0080000000FFC080
##    sleep .085
#
#counterx=8
#while [ $counterx -gt 0 ]; do
##	cansend vcan2 001#0000000000000000
#	#cansend can0 133#0208000800000000
#	cansend can0 641#242020202020202B
#    sleep .02
#    #cansend can0 401#0080004000FFC080
#    #cansend can0 401#0080004000FFC080
#    let counterx-=1
#    echo $counterx
#
#    sleep .08
#done
#
#counte=2
#while [ $counte -gt 0 ]; do
##	cansend vcan2 001#0000000000000000
#	#cansend can0 133#0200000000000000
#	cansend can0 641#242020202020202B
#    sleep .02
#    #cansend can0 401#0080000000FFC080
#    #cansend can0 401#0080004000FFC080
#    let counte-=1
#    echo $counte
#
#    sleep .08
#done
#
sudo ip link set can0 down 
    exit 0 
