
#!/bin/bash

#sudo ip link set can0 type can bitrate 500000
#sudo ip link set can0 up
#counter=42
#while [ $counter -gt 0 ]; do

if [ -z $2 ]; then
    counter=5000
else
    counter=$2
fi

if [ -z $1 ]; then
    file_Name=complete.log
else
    file_Name=$1
fi

while read line; do
    if [ $counter -eq 0 ]; then 
        break
    fi

    cansend can0 $line 
 #   echo $line
    sleep .004
    let counter-=1

done < "$1"

#sudo ip link set can0 down 
exit 0 
