
#!/bin/bash

sudo ip link set can0 down
exit 0
