#!/bin/bash
if [ -z $1 ]; then 
  interface=can0
else
  interface=$1
fi


function initialize {
  sudo ip link set $1 type can bitrate 500000
  sudo ip link set $1 up
}


initialize $interface
