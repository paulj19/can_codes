#get all the packets from of the given id in the log
#usage packets_from_id.py input_file output_file can_id 

import sys

#get sorted set of ids from log1

f = open(sys.argv[2], 'w')
set_canid_log1 = list()
with open(sys.argv[1], 'r') as source_file:
    for line in source_file:
        index1_canid = line.find('#')
        if(line.find(sys.argv[3], index1_canid - 3, index1_canid) != -1):
            f.write(line)
            print(line)

#            index1_canid = line.find('#')
#        set_canid_log1.add(line[index1_canid-3 : index1_canid])
#sorted_canIdList_log1 = set(sorted(set_canid_log1))





