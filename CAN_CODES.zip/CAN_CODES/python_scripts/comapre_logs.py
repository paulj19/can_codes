#prints the ids present in first log not in sencond and vice versa
#usage compare_ids.py file1.log file2.log
import sys

#get sorted set of ids from log1

set_canid_log1 = set()
with open(sys.argv[1], 'r') as source_file:
    for line in source_file:
        index1_canid = line.find('#')
        set_canid_log1.add(line[index1_canid-3 : index1_canid])
sorted_canIdList_log1 = set(sorted(set_canid_log1))


#get sorted set of ids from log2

set_canid_log2 = set()
with open(sys.argv[2], 'r') as source_file:
    for line in source_file:
        index2_canid = line.find('#')
        set_canid_log2.add(line[index2_canid-3 : index2_canid])
sorted_canIdList_log2 = set(sorted(set_canid_log2))


print("----------------log1 - log2----------------")
print(sorted_canIdList_log1.difference(sorted_canIdList_log2))

print("----------------log2 - log1----------------")
print(sorted_canIdList_log2.difference(sorted_canIdList_log1))



