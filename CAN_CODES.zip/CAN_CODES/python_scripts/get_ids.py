import sys

set_canid = set()
with open(sys.argv[1], 'r') as source_file:
    for line in source_file:
        index_canid = line.find('#')
        set_canid.add(line[index_canid-3 : index_canid])
print(sorted(set_canid))


